library(testthat)
library(tidylda)

test_check("tidylda")
